export type Product = {
  id: number;
  title: string;
  desc: string;
  category: string;
  subcategory: string;
  price: string;
  // مشخصات اختیاری برای هاست/سرور
  storage?: string; // فضای دیسک
  bandwidth?: string; // پهنای باند
  uptime?: string; // آپتایم
  panel?: string; // کنترل پنل
  ssl?: string; // SSL
  backups?: string; // بکاپ
};

export const allProducts: Product[] = [
  { id: 1, title: "هاست ایرانی پایه", desc: "مناسب سایت‌های تازه‌کار", category: "هاست", subcategory: "هاست ایرانی", price: "۵۰,۰۰۰", storage: "10GB SSD", bandwidth: "100GB", uptime: "99.9%", panel: "DirectAdmin", ssl: "رایگان", backups: "روزانه" },
  { id: 2, title: "هاست خارجی حرفه‌ای", desc: "پایداری و سرعت بالا", category: "هاست", subcategory: "هاست خارجی", price: "۱۵۰,۰۰۰", storage: "20GB SSD", bandwidth: "نامحدود", uptime: "99.99%", panel: "cPanel", ssl: "رایگان", backups: "روزانه/هفتگی" },
  { id: 3, title: "سرور ایرانی", desc: "قدرت پردازشی برای پروژه‌های داخلی", category: "سرور", subcategory: "سرور ایرانی", price: "۵۰۰,۰۰۰" },
  { id: 4, title: "سرور خارجی", desc: "آپ‌تایم بالا و منابع اختصاصی", category: "سرور", subcategory: "سرور خارجی", price: "۹۰۰,۰۰۰" },
  { id: 5, title: "سایت فروشگاهی", desc: "راه‌اندازی سریع فروش آنلاین", category: "سایت", subcategory: "فروشگاهی", price: "۲,۰۰۰,۰۰۰" },
  { id: 6, title: "سایت شرکتی", desc: "اعتبار برند و معرفی خدمات", category: "سایت", subcategory: "شرکتی", price: "۱,۵۰۰,۰۰۰" },
  { id: 7, title: "وبلاگ حرفه‌ای", desc: "انتشار محتوا و مقالات", category: "سایت", subcategory: "وبلاگ", price: "۸۰۰,۰۰۰" },
  { id: 8, title: "اپلیکیشن فروشگاهی", desc: "Android و iOS", category: "اپلیکیشن", subcategory: "فروشگاهی", price: "۵,۰۰۰,۰۰۰" },
  { id: 9, title: "ربات تلگرام", desc: "اتوماسیون و فروش", category: "ربات", subcategory: "تلگرام", price: "۱,۵۰۰,۰۰۰" },
  { id: 10, title: "تولید ویدیو", desc: "ویدیو مارکتینگ حرفه‌ای", category: "تولید محتوا", subcategory: "تولید ویدیو", price: "۱,۸۰۰,۰۰۰" },
];

export function findProductById(id: number): Product | undefined {
  return allProducts.find((p) => p.id === id);
}


