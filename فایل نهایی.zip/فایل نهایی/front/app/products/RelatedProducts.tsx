"use client";

import { useState } from "react";
import Link from "next/link";
import type { Product } from "./data";

export default function RelatedProducts({ items }: { items: Product[] }) {
  const [page, setPage] = useState(0);
  const pageSize = 4;
  const numPages = Math.ceil(items.length / pageSize);
  const paged = items.slice(page * pageSize, page * pageSize + pageSize);

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {paged.map((p) => (
          <div key={p.id} className="border rounded-2xl p-4">
            <div className="font-semibold mb-1">{p.title}</div>
            <div className="text-foreground/70 text-sm mb-3">{p.desc}</div>
            <div className="flex items-center justify-between">
              <span className="text-green-500 text-sm font-bold">{p.price} تومان</span>
              <Link href={`/products/${p.id}`} className="rounded-lg border px-3 py-1 text-sm hover:bg-blue-600 hover:text-white">مشاهده</Link>
            </div>
          </div>
        ))}
      </div>
      {numPages > 1 && (
        <div className="mt-4 flex items-center justify-center gap-2">
          {Array.from({ length: numPages }).map((_, i) => (
            <button
              key={i}
              className={`rounded-full w-9 h-9 border text-sm ${i === page ? "bg-blue-600 text-white border-blue-600" : "hover:bg-blue-50"}`}
              onClick={() => setPage(i)}
            >
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}


