"use client";

import { FormEvent, useState } from "react";
import Image from "next/image";

export default function AccountAuthPage() {
  const [showPass, setShowPass] = useState(false);
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    mobile: "",
    nationalCode: "",
    password: "",
    confirm: "",
  });

  async function submitForm(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!form.email.trim() || !form.password || !form.firstName.trim() || !form.lastName.trim()) {
      alert("فیلدهای الزامی را تکمیل کنید.");
      return;
    }
    if (form.password !== form.confirm) {
      alert("تکرار رمز با رمز عبور یکسان نیست.");
      return;
    }
    const res = await fetch("/api/account/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    if (res.ok) {
      alert("ثبت‌نام انجام شد.");
             setForm({
         firstName: "",
         lastName: "",
         email: "",
         mobile: "",
         nationalCode: "",
         password: "",
         confirm: "",
       });
    } else {
      alert("ثبت‌نام ناموفق بود.");
    }
  }

  return (
    <section className="mt-6 sm:mt-8">
      <div className="mx-auto w-full max-w-2xl space-y-5">


        <form onSubmit={submitForm} className="grid grid-cols-1 sm:grid-cols-2 gap-4 border rounded-2xl p-5 bg-background">
          <div>
            <label className="block text-sm mb-1">نام *</label>
            <input
              required
              className="w-full rounded-lg border px-3 py-2 bg-transparent"
              value={form.firstName}
              onChange={(e) => setForm((f) => ({ ...f, firstName: e.target.value }))}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">نام خانوادگی *</label>
            <input
              required
              className="w-full rounded-lg border px-3 py-2 bg-transparent"
              value={form.lastName}
              onChange={(e) => setForm((f) => ({ ...f, lastName: e.target.value }))}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">ایمیل *</label>
            <input
              type="email"
              required
              className="w-full rounded-lg border px-3 py-2 bg-transparent ltr:text-left"
              placeholder="you@example.com"
              value={form.email}
              onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">شماره موبایل</label>
            <input
              className="w-full rounded-lg border px-3 py-2 bg-transparent"
              placeholder="0912xxxxxxx"
              value={form.mobile}
              onChange={(e) => setForm((f) => ({ ...f, mobile: e.target.value }))}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">کد ملی</label>
            <input
              className="w-full rounded-lg border px-3 py-2 bg-transparent"
              placeholder="مثال: 0012345678"
              value={form.nationalCode}
              onChange={(e) => setForm((f) => ({ ...f, nationalCode: e.target.value }))}
            />
          </div>
          <div>
            <label className="block text-sm mb-1">رمز عبور *</label>
            <div className="flex items-center gap-2">
              <input
                type={showPass ? "text" : "password"}
                required
                className="w-full rounded-lg border px-3 py-2 bg-transparent ltr:text-left"
                placeholder="********"
                value={form.password}
                onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
              />
              <button type="button" className="rounded border px-3 py-2 text-xs hover:bg-primary hover:text-white" onClick={() => setShowPass((s) => !s)}>
                {showPass ? "مخفی" : "نمایش"}
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm mb-1">تکرار رمز *</label>
            <input
              type="password"
              required
              className="w-full rounded-lg border px-3 py-2 bg-transparent ltr:text-left"
              placeholder="********"
              value={form.confirm}
              onChange={(e) => setForm((f) => ({ ...f, confirm: e.target.value }))}
            />
          </div>

          <div className="sm:col-span-2 flex justify-center">
            <button className="rounded-xl bg-primary text-white px-5 py-2 text-base hover:bg-primary-light">ثبت‌نام</button>
          </div>
        </form>
      </div>
    </section>
  );
}


