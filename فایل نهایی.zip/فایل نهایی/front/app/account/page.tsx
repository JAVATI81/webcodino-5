import Link from "next/link";

const actionCards: Array<{ href: string; label: string; icon: string; color?: string }> = [
  { href: "/account/orders", label: "سفارشهای من", icon: "📦" },
  { href: "/account/cart", label: "سبد خرید", icon: "🛒" },
  { href: "/account/subscriptions", label: "اشتراک های من", icon: "📄" },
  { href: "/account/tickets", label: "تیکت پشتیبانی", icon: "📧" },
  { href: "/account/coupons", label: "کدهای تخفیف", icon: "🎁" },
  { href: "/account/change-password", label: "تغییر رمز", icon: "🔑" },
  { href: "/account/auth", label: "احراز هویت", icon: "🔒" },
  { href: "/account/logout", label: "خروج", icon: "🚪", color: "border-red-500" },
];

const statsCards: Array<{ label: string; count: number }> = [
  { label: "کدهای تخفیف", count: 0 },
  { label: "تیکت های باز", count: 0 },
  { label: "محصولات سبد خرید", count: 0 },
  { label: "سفارشات فعال", count: 0 },
];

export default function AccountIndexPage() {
  return (
    <section className="mt-6 sm:mt-8 space-y-6">
      {/* Welcome Section */}
      <div className="bg-background border rounded-2xl p-6 flex items-center gap-4">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
          <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
            <circle cx="12" cy="7.5" r="3.5" />
            <path d="M4 20c0-3.8 4-6.5 8-6.5s8 2.7 8 6.5" />
          </svg>
        </div>
        <div>
          <h2 className="text-xl font-bold">خوش آمدید، کاربر تست</h2>
          <p className="text-foreground/70">test@example.com</p>
        </div>
      </div>

      {/* Action Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {actionCards.map((card) => (
          <Link
            key={card.href}
            href={card.href}
            className={`bg-background border rounded-2xl p-4 text-center hover:bg-primary hover:text-white transition-colors ${card.color || ''}`}
          >
            <div className="text-2xl mb-2">{card.icon}</div>
            <div className="text-sm font-medium">{card.label}</div>
          </Link>
        ))}
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {statsCards.map((stat) => (
          <div key={stat.label} className="bg-background border rounded-2xl p-4 text-center">
            <div className="text-2xl font-bold text-primary">{stat.count}</div>
            <div className="text-sm text-foreground/70">{stat.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}


