"use client";

import { useState, FormEvent, useEffect } from "react";
import type { Ticket } from "@/app/api/account/tickets/route";

export default function TicketsPage() {
  const [selected, setSelected] = useState<Ticket | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [rows, setRows] = useState<Ticket[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setIsLoading(true);
        const res = await fetch("/api/account/tickets", { cache: "no-store" });
        const data = await res.json();
        if (alive) setRows(Array.isArray(data?.items) ? data.items : []);
      } finally {
        if (alive) setIsLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);
  type AdminMessage = {
    id: string;
    subject: string;
    body: string;
    createdAt: string;
    read: boolean;
  };
  const initialAdminMessages: AdminMessage[] = [
    {
      id: "AM-1001",
      subject: "اطلاعیه مهم درباره نگهداری سرور",
      body:
        "کاربر گرامی، به اطلاع می‌رسد امشب ساعت ۲۳ تا ۲۴ عملیات نگهداری انجام می‌شود و ممکن است اختلالاتی رخ دهد.",
      createdAt: "1403/05/20",
      read: false,
    },
  ];
  const [adminMessages, setAdminMessages] = useState<AdminMessage[]>(initialAdminMessages);

  async function submitNewTicket(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    try {
      const res = await fetch("/api/account/tickets", { method: "POST" });
      if (res.ok) {
        setShowNew(false);
        alert("تیکت شما ثبت شد و به‌زودی پاسخ داده می‌شود.");
      }
    } catch {
      // noop
    }
  }

  function markMessageAsRead(id: string) {
    setAdminMessages((prev) => prev.map((m) => (m.id === id ? { ...m, read: true } : m)));
  }

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">تیکت‌های پشتیبانی</h1>
        <button
          className="rounded-xl bg-primary text-white px-5 py-2 text-base hover:bg-primary-light"
          onClick={() => setShowNew(true)}
        >
          ثبت تیکت
        </button>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-primary">{rows.length}</div>
          <div className="text-sm text-foreground/70">کل تیکت‌ها</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-primary">{rows.filter(t => t.status === "باز").length}</div>
          <div className="text-sm text-foreground/70">تیکت‌های باز</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-primary">{rows.filter(t => t.status === "پاسخ داده شده").length}</div>
          <div className="text-sm text-foreground/70">پاسخ داده شده</div>
        </div>
        <div className="bg-background border rounded-2xl p-4 text-center">
          <div className="text-2xl font-bold text-primary">{adminMessages.filter(m => !m.read).length}</div>
          <div className="text-sm text-foreground/70">پیام‌های جدید</div>
        </div>
      </div>

      {adminMessages.length > 0 && (
        <div className="border rounded-2xl p-4 space-y-3 bg-background">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold">پیام‌های ارسالی ادمین</h2>
            <span className="text-xs rounded-full bg-primary/20 text-primary px-2 py-0.5">
              {adminMessages.filter((m) => !m.read).length} جدید
            </span>
          </div>
          <ul className="space-y-3">
            {adminMessages.map((m) => (
              <li
                key={m.id}
                className={`rounded-xl border p-3 ${m.read ? "opacity-70" : "bg-primary/10 border-primary/30"}`}
              >
                <div className="flex items-center justify-between gap-3 mb-1">
                  <div className="flex items-center gap-2">
                    {!m.read && <span className="inline-block size-2 rounded-full bg-primary" aria-hidden />}
                    <span className="font-semibold">{m.subject}</span>
                  </div>
                  <span className="text-xs text-foreground/70">{m.createdAt}</span>
                </div>
                <p className="text-sm leading-7">{m.body}</p>
                {!m.read && (
                  <div className="mt-2">
                    <button
                      className="rounded border px-3 py-1 text-sm hover:bg-primary hover:text-white"
                      onClick={() => markMessageAsRead(m.id)}
                    >
                      علامت خوانده شد
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="border rounded-xl [direction:ltr] bg-background">
        <div className="max-h-[60vh] overflow-y-auto">
          <div className="[direction:rtl] overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-primary/10 text-foreground/80">
                <tr>
                  <th className="p-3 text-right">کد</th>
                  <th className="p-3 text-right">موضوع</th>
                  <th className="p-3 text-right">تاریخ</th>
                  <th className="p-3 text-right">وضعیت</th>
                  <th className="p-3 text-right">سوال</th>
                  <th className="p-3 text-right">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {isLoading && (
                  <tr><td className="p-3 text-center" colSpan={6}>در حال بارگذاری...</td></tr>
                )}
                {!isLoading && rows.map((t) => (
                  <tr key={t.id} className="border-t">
                    <td className="p-3">{t.id}</td>
                    <td className="p-3">{t.subject}</td>
                    <td className="p-3">{t.createdAt}</td>
                    <td className="p-3">{t.status}</td>
                    <td className="p-3 line-clamp-2 max-w-[260px]">{t.question}</td>
                    <td className="p-3">
                      <button
                        className="rounded border px-3 py-1 hover:bg-primary hover:text-white"
                        onClick={() => setSelected(t)}
                      >
                        مشاهده پاسخ
                      </button>
                    </td>
                  </tr>
                ))}
                {!isLoading && rows.length === 0 && (
                  <tr><td className="p-3 text-center text-foreground/70" colSpan={6}>تیکتی یافت نشد.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {selected && (
        <div className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-xl rounded-2xl border bg-background p-5 shadow-xl [direction:rtl]">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">پاسخ تیکت {selected.id}</h2>
                              <button className="rounded px-3 py-1 border hover:bg-primary hover:text-white" onClick={() => setSelected(null)}>بستن</button>
            </div>
            <div className="space-y-3 text-sm">
              <div><span className="text-foreground/70">موضوع:</span> {selected.subject}</div>
              <div>
                <div className="text-foreground/70 mb-1">سوال شما:</div>
                <p className="leading-7">{selected.question}</p>
              </div>
              <div>
                <div className="text-foreground/70 mb-1">پاسخ:</div>
                <p className="leading-7">{selected.answer ?? "هنوز پاسخی ثبت نشده است."}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {showNew && (
        <div className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-xl rounded-2xl border bg-background p-5 shadow-xl [direction:rtl]">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">ثبت تیکت جدید</h2>
                              <button className="rounded px-3 py-1 border hover:bg-primary hover:text-white" onClick={() => setShowNew(false)}>بستن</button>
            </div>
            <form onSubmit={submitNewTicket} className="grid grid-cols-1 gap-3">
              <div>
                <label className="block text-sm mb-1">موضوع</label>
                <select
                  required
                  defaultValue=""
                  dir="rtl"
                  className="block w-full min-w-0 rounded-lg border px-3 py-2 bg-transparent text-right"
                >
                  <option value="" disabled className="text-black" style={{ color: "#000" }}>
                    انتخاب کنید...
                  </option>
                  <option value="technical" className="text-black" style={{ color: "#000" }}>
                    مشکل فنی
                  </option>
                  <option value="billing" className="text-black" style={{ color: "#000" }}>
                    صورتحساب / مالی
                  </option>
                  <option value="renew" className="text-black" style={{ color: "#000" }}>
                    تمدید / لغو سرویس
                  </option>
                  <option value="consult" className="text-black" style={{ color: "#000" }}>
                    مشاوره
                  </option>
                  <option value="other" className="text-black" style={{ color: "#000" }}>
                    سایر
                  </option>
                </select>
              </div>
              <div>
                <label className="block text-sm mb-1">متن پیام</label>
                <textarea required rows={6} className="w-full rounded-lg border px-3 py-2 bg-transparent" placeholder="پیام خود را بنویسید..." />
              </div>
              <div className="flex justify-end">
                <button className="rounded-xl bg-primary text-white px-5 py-2 text-base hover:bg-primary-light">ارسال تیکت</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}


