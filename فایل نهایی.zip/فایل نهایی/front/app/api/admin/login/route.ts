import { NextResponse } from "next/server";

// POST /api/admin/login
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  if (!body?.identifier || !body?.password) {
    return NextResponse.json({ error: "invalid" }, { status: 400 });
  }
  // اینجا احراز هویت ادمین انجام می‌شود
  return NextResponse.json({ ok: true, token: "admin-mock-token" });
}


