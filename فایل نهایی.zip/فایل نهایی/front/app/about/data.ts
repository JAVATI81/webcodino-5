export type AboutItem = {
  slug: string;
  title: string;
  content: string;
};

export const aboutItems: AboutItem[] = [
  {
    slug: "mission",
    title: "ماموریت ما",
    content:
      "ماموریت وب‌کدینو کمک به رشد کسب‌وکارها با ارائه راهکارهای دیجیتال ایمن، سریع و مقیاس‌پذیر است.",
  },
  {
    slug: "vision",
    title: "چشم‌انداز",
    content:
      "ساخت اکوسیستمی که ایده‌ها در آن به محصولات دیجیتال موفق تبدیل شوند و ارزش پایدار خلق کنند.",
  },
  {
    slug: "values",
    title: "ارزش‌ها",
    content:
      "شفافیت، کیفیت، تعهد، و یادگیری مستمر اصول محوری ما در همکاری با مشتریان هستند.",
  },
  {
    slug: "process",
    title: "فرآیند همکاری",
    content:
      "از تحلیل نیاز تا طراحی UI/UX، توسعه، تضمین کیفیت و پشتیبانی در کنار شما هستیم.",
  },
  {
    slug: "team",
    title: "تیم ما",
    content:
      "تیمی چندرشته‌ای از طراحان، توسعه‌دهندگان، متخصصان DevOps و بازاریابی دیجیتال.",
  },
];

export function findAboutItem(slug: string): AboutItem | undefined {
  return aboutItems.find((i) => i.slug === slug);
}


