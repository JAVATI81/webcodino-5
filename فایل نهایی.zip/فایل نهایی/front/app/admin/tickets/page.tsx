"use client";

import { useEffect, useMemo, useState, FormEvent } from "react";

type Ticket = {
  id: string;
  subject: string;
  question: string;
  answer?: string;
  status: "پاسخ داده شد" | "در انتظار پاسخ";
  createdAt: string;
};

type AdminTicket = Ticket & {
  userName: string;
};

const seedTickets: AdminTicket[] = [];

export default function AdminTicketsPage() {
  const [rows, setRows] = useState<AdminTicket[]>(seedTickets);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("همه");
  const [dateFilter, setDateFilter] = useState<string>("همه");
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setIsLoading(true);
        const res = await fetch("/api/admin/tickets", { cache: "no-store" });
        const data = await res.json();
        if (alive) setRows(Array.isArray(data?.items) ? data.items : []);
      } finally {
        if (alive) setIsLoading(false);
      }
    })();
    return () => { alive = false; };
  }, []);
  const [viewing, setViewing] = useState<AdminTicket | null>(null);
  const [answering, setAnswering] = useState<AdminTicket | null>(null);
  const [answerDraft, setAnswerDraft] = useState<string>("");
  const [showMessage, setShowMessage] = useState<boolean>(false);
  const [msgForm, setMsgForm] = useState({
    recipientEmail: "",
    recipientAccount: "",
    subject: "",
    body: "",
    sendToEmail: true,
    sendToAccount: true,
  });

  function openView(row: AdminTicket) {
    setViewing(row);
  }

  function openAnswer(row: AdminTicket) {
    setAnswering(row);
    setAnswerDraft(row.answer ?? "");
  }

  function saveAnswer() {
    if (!answering) return;
    const updated: AdminTicket = {
      ...answering,
      answer: answerDraft.trim(),
      status: "پاسخ داده شد",
    };
    setRows((prev) => prev.map((r) => (r.id === updated.id ? updated : r)));
    setAnswering(null);
    setAnswerDraft("");
  }

  function submitMessage(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const { recipientEmail, recipientAccount, subject, body, sendToEmail, sendToAccount } = msgForm;
    if (!sendToEmail && !sendToAccount) {
      if (typeof window !== "undefined") alert("حداقل یکی از گزینه‌های ارسال (ایمیل/حساب کاربری) را انتخاب کنید.");
      return;
    }
    if (sendToEmail && !recipientEmail.trim()) {
      if (typeof window !== "undefined") alert("ایمیل کاربر را وارد کنید.");
      return;
    }
    if (sendToAccount && !recipientAccount.trim()) {
      if (typeof window !== "undefined") alert("شناسه حساب کاربری را وارد کنید.");
      return;
    }
    if (!subject.trim() || !body.trim()) {
      if (typeof window !== "undefined") alert("عنوان و متن پیام الزامی است.");
      return;
    }
    if (typeof window !== "undefined") alert("پیام ارسال شد (شبیه‌سازی).");
    setShowMessage(false);
    setMsgForm({ recipientEmail: "", recipientAccount: "", subject: "", body: "", sendToEmail: true, sendToAccount: true });
  }

  // فیلتر کردن تیکت‌ها
  const filteredTickets = useMemo(() => {
    return rows.filter((ticket) => {
      const matchesSearch = 
        ticket.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        ticket.question.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === "همه" || ticket.status === statusFilter;
      
      // فیلتر تاریخ بهبود یافته
      let matchesDate = true;
      if (dateFilter !== "همه") {
        const ticketDateParts = ticket.createdAt.split('/');
        const filterDateParts = dateFilter.split('/');
        
        if (filterDateParts.length === 2) {
          // فیلتر بر اساس سال و ماه (مثل 1403/05)
          matchesDate = ticketDateParts.length >= 2 && 
                       ticketDateParts[0] === filterDateParts[0] && 
                       ticketDateParts[1] === filterDateParts[1];
        } else if (filterDateParts.length === 1) {
          // فیلتر بر اساس سال (مثل 1403)
          matchesDate = ticketDateParts.length >= 1 && ticketDateParts[0] === filterDateParts[0];
        }
      }
      
      return matchesSearch && matchesStatus && matchesDate;
    });
  }, [rows, searchTerm, statusFilter, dateFilter]);

  return (
    <section className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">مدیریت تیکت‌ها</h1>
        <button
          className="rounded-xl bg-primary text-white px-4 py-2 text-sm hover:bg-primary-light"
          onClick={() => setShowMessage(true)}
        >
          پیام به کاربر
        </button>
      </div>

      {/* فیلترها و جستجو */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm mb-1">جستجو</label>
          <input
            type="text"
            placeholder="جستجو در کد، موضوع، نام کاربر یا سوال..."
            className="w-full rounded-lg border px-3 py-2 bg-background"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm mb-1">وضعیت</label>
          <select
            className="w-full rounded-lg border px-3 py-2 bg-background [&>option]:bg-black [&>option]:text-white"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="همه">همه</option>
            <option value="پاسخ داده شد">پاسخ داده شد</option>
            <option value="در انتظار پاسخ">در انتظار پاسخ</option>
          </select>
        </div>
        <div>
          <label className="block text-sm mb-1">تاریخ</label>
          <select
            className="w-full rounded-lg border px-3 py-2 bg-background [&>option]:bg-black [&>option]:text-white"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
          >
            <option value="همه">همه</option>
            <option value="1403/05">خرداد 1403</option>
            <option value="1403/04">اردیبهشت 1403</option>
            <option value="1403/03">فروردین 1403</option>
          </select>
        </div>
        <div className="flex items-end">
          <button
            onClick={() => {
              setSearchTerm("");
              setStatusFilter("همه");
              setDateFilter("همه");
            }}
            className="w-full rounded-lg border px-3 py-2 bg-background hover:bg-primary hover:text-white"
          >
            پاک کردن فیلترها
          </button>
        </div>
      </div>
      <div className="border rounded-xl [direction:ltr] bg-background">
        <div className="max-h-[60vh] overflow-y-auto pr-2 [scrollbar-gutter:stable]">
          <div className="[direction:rtl] overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-primary/10 text-foreground/80">
                <tr>
                  <th className="p-3 text-right">کد</th>
                  <th className="p-3 text-right">موضوع</th>
                  <th className="p-3 text-right">نام کاربر</th>
                  <th className="p-3 text-right">تاریخ</th>
                  <th className="p-3 text-right">وضعیت</th>
                  <th className="p-3 text-right">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {isLoading && (
                  <tr><td className="p-3 text-center" colSpan={6}>در حال بارگذاری...</td></tr>
                )}
                {!isLoading && filteredTickets.map((t) => (
                  <tr key={t.id} className="border-t">
                    <td className="p-3">{t.id}</td>
                    <td className="p-3">{t.subject}</td>
                    <td className="p-3">{t.userName}</td>
                    <td className="p-3">{t.createdAt}</td>
                    <td className="p-3">{t.status}</td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        <button
                          className="rounded border px-3 py-1 bg-background hover:bg-primary hover:text-white"
                          onClick={() => openView(t)}
                        >
                          مشاهده سوال
                        </button>
                        <button
                          className="rounded border px-3 py-1 bg-background hover:bg-primary hover:text-white"
                          onClick={() => openAnswer(t)}
                        >
                          پاسخ
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {!isLoading && filteredTickets.length === 0 && (
                  <tr><td className="p-3 text-center text-foreground/70" colSpan={6}>
                    {rows.length === 0 ? "تیکتی یافت نشد." : "نتیجه‌ای برای فیلترهای انتخابی یافت نشد."}
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {viewing && (
        <div
          className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-xl rounded-2xl border bg-background p-5 shadow-xl [direction:rtl]">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">مشاهده تیکت {viewing.id}</h2>
              <button className="rounded px-3 py-1 border hover:bg-blue-600 hover:text-white" onClick={() => setViewing(null)}>
                بستن
              </button>
            </div>
            <div className="space-y-3 text-sm">
              <div>
                <span className="text-foreground/70">کاربر:</span> {viewing.userName}
              </div>
              <div>
                <span className="text-foreground/70">موضوع:</span> {viewing.subject}
              </div>
              <div>
                <div className="text-foreground/70 mb-1">سوال:</div>
                <p className="leading-7">{viewing.question}</p>
              </div>
              <div>
                <div className="text-foreground/70 mb-1">پاسخ:</div>
                <p className="leading-7">{viewing.answer ?? "هنوز پاسخی ثبت نشده است."}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {answering && (
        <div
          className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-xl rounded-2xl border bg-background p-5 shadow-xl [direction:rtl]">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">پاسخ به تیکت {answering.id}</h2>
              <button className="rounded px-3 py-1 border hover:bg-blue-600 hover:text-white" onClick={() => setAnswering(null)}>
                بستن
              </button>
            </div>
            <div className="space-y-3 text-sm">
              <div>
                <span className="text-foreground/70">کاربر:</span> {answering.userName}
              </div>
              <div>
                <span className="text-foreground/70">موضوع:</span> {answering.subject}
              </div>
              <div>
                <div className="text-foreground/70 mb-1">سوال:</div>
                <p className="leading-7">{answering.question}</p>
              </div>
              <div>
                <label className="block text-sm mb-1">پاسخ شما</label>
                <textarea
                  rows={6}
                  className="w-full rounded-lg border px-3 py-2 bg-transparent"
                  placeholder="پاسخ خود را بنویسید..."
                  value={answerDraft}
                  onChange={(e) => setAnswerDraft(e.target.value)}
                />
              </div>
              <div className="flex items-center justify-end gap-2">
                <button className="rounded border px-4 py-2 hover:bg-blue-600 hover:text-white" onClick={() => setAnswering(null)}>
                  انصراف
                </button>
                <button className="rounded bg-blue-600 text-white px-5 py-2 hover:bg-blue-700" onClick={saveAnswer}>
                  ثبت پاسخ
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showMessage && (
        <div className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-xl rounded-2xl border bg-background p-5 shadow-xl [direction:rtl]">
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">ارسال پیام به کاربر</h2>
              <button className="rounded px-3 py-1 border hover:bg-blue-600 hover:text-white" onClick={() => setShowMessage(false)}>بستن</button>
            </div>
            <form onSubmit={submitMessage} className="grid grid-cols-1 gap-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm mb-1">ایمیل کاربر</label>
                  <input
                    type="email"
                    className="w-full rounded border px-3 py-2 ltr:text-left"
                    value={msgForm.recipientEmail}
                    onChange={(e) => setMsgForm((f) => ({ ...f, recipientEmail: e.target.value }))}
                    placeholder="user@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">شناسه حساب کاربری</label>
                  <input
                    className="w-full rounded border px-3 py-2"
                    value={msgForm.recipientAccount}
                    onChange={(e) => setMsgForm((f) => ({ ...f, recipientAccount: e.target.value }))}
                    placeholder="مثلاً user-123"
                  />
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="size-4 accent-blue-600"
                    checked={msgForm.sendToEmail}
                    onChange={(e) => setMsgForm((f) => ({ ...f, sendToEmail: e.target.checked }))}
                  />
                  <span>ارسال به ایمیل</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    className="size-4 accent-blue-600"
                    checked={msgForm.sendToAccount}
                    onChange={(e) => setMsgForm((f) => ({ ...f, sendToAccount: e.target.checked }))}
                  />
                  <span>ارسال به حساب کاربری</span>
                </label>
              </div>
              <div>
                <label className="block text-sm mb-1">عنوان پیام</label>
                <input
                  className="w-full rounded border px-3 py-2"
                  value={msgForm.subject}
                  onChange={(e) => setMsgForm((f) => ({ ...f, subject: e.target.value }))}
                  placeholder="عنوان"
                />
              </div>
              <div>
                <label className="block text-sm mb-1">متن پیام</label>
                <textarea
                  rows={6}
                  className="w-full rounded border px-3 py-2"
                  value={msgForm.body}
                  onChange={(e) => setMsgForm((f) => ({ ...f, body: e.target.value }))}
                  placeholder="متن پیام..."
                />
              </div>
              <div className="flex items-center justify-end gap-2">
                <button type="button" className="rounded border px-4 py-2 hover:bg-blue-600 hover:text-white" onClick={() => setShowMessage(false)}>انصراف</button>
                <button type="submit" className="rounded bg-blue-600 text-white px-5 py-2 hover:bg-blue-700">ارسال پیام</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}


