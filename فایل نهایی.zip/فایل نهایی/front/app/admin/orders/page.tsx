"use client";

import { useEffect, useState, useMemo } from "react";
import type { OrderRow } from "@/app/account/orders/data";

type OrderStatus = OrderRow["status"];
type AdminOrderRow = OrderRow & { userName: string; userNationalId: string };

export default function AdminOrdersPage() {
  const [rows, setRows] = useState<AdminOrderRow[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("همه");
  const [dateFilter, setDateFilter] = useState<string>("همه");
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setIsLoading(true);
        const res = await fetch("/api/admin/orders", { cache: "no-store" });
        const data = await res.json();
        if (alive) setRows(Array.isArray(data?.items) ? data.items : []);
      } finally {
        if (alive) setIsLoading(false);
      }
    })();
    return () => { alive = false; };
  }, []);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draftStatus, setDraftStatus] = useState<OrderStatus>("پرداخت شده");

  function startEdit(row: OrderRow) {
    setEditingId(row.id);
    setDraftStatus(row.status);
  }

  function cancelEdit() {
    setEditingId(null);
  }

  function saveEdit() {
    setRows((prev) => prev.map((r) => (r.id === editingId ? { ...r, status: draftStatus } : r)));
    setEditingId(null);
  }

  // فیلتر کردن سفارشات
  const filteredOrders = useMemo(() => {
    return rows.filter((order) => {
      const matchesSearch = 
        order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        order.userNationalId.includes(searchTerm) ||
        order.items.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === "همه" || order.status === statusFilter;
      
      // فیلتر تاریخ بهبود یافته
      let matchesDate = true;
      if (dateFilter !== "همه") {
        const orderDateParts = order.date.split('/');
        const filterDateParts = dateFilter.split('/');
        
        if (filterDateParts.length === 2) {
          // فیلتر بر اساس سال و ماه (مثل 1403/05)
          matchesDate = orderDateParts.length >= 2 && 
                       orderDateParts[0] === filterDateParts[0] && 
                       orderDateParts[1] === filterDateParts[1];
        } else if (filterDateParts.length === 1) {
          // فیلتر بر اساس سال (مثل 1403)
          matchesDate = orderDateParts.length >= 1 && orderDateParts[0] === filterDateParts[0];
        }
      }
      
      return matchesSearch && matchesStatus && matchesDate;
    });
  }, [rows, searchTerm, statusFilter, dateFilter]);

  return (
    <section className="space-y-6">
      <h1 className="text-2xl font-bold">مدیریت سفارشات</h1>

      {/* فیلترها و جستجو */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm mb-1">جستجو</label>
          <input
            type="text"
            placeholder="جستجو در کد سفارش، نام کاربر، کد ملی یا اقلام..."
            className="w-full rounded-lg border px-3 py-2 bg-background"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm mb-1">وضعیت</label>
          <select
            className="w-full rounded-lg border px-3 py-2 bg-background [&>option]:bg-black [&>option]:text-white"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="همه">همه</option>
            <option value="پرداخت شده">پرداخت شده</option>
            <option value="در حال پردازش">در حال پردازش</option>
            <option value="مرجوع">مرجوع</option>
          </select>
        </div>
        <div>
          <label className="block text-sm mb-1">تاریخ</label>
          <select
            className="w-full rounded-lg border px-3 py-2 bg-background [&>option]:bg-black [&>option]:text-white"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
          >
            <option value="همه">همه</option>
            <option value="1403/05">خرداد 1403</option>
            <option value="1403/04">اردیبهشت 1403</option>
            <option value="1403/03">فروردین 1403</option>
          </select>
        </div>
        <div className="flex items-end">
          <button
            onClick={() => {
              setSearchTerm("");
              setStatusFilter("همه");
              setDateFilter("همه");
            }}
            className="w-full rounded-lg border px-3 py-2 bg-background hover:bg-primary hover:text-white"
          >
            پاک کردن فیلترها
          </button>
        </div>
      </div>
      <div className="border rounded-xl [direction:ltr] bg-background">
        <div className="max-h-[60vh] overflow-y-auto pr-2 [scrollbar-gutter:stable]">
          <div className="[direction:rtl] overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-primary/10 text-foreground/80">
                <tr>
                  <th className="p-3 text-right">کد سفارش</th>
                  <th className="p-3 text-right">تاریخ</th>
                  <th className="p-3 text-right">اقلام</th>
                  <th className="p-3 text-right">نام کاربر</th>
                  <th className="p-3 text-right">کد ملی</th>
                  <th className="p-3 text-right">مبلغ</th>
                  <th className="p-3 text-right">وضعیت</th>
                  <th className="p-3 text-right">عملیات</th>
                </tr>
              </thead>
              <tbody>
                {isLoading && (
                  <tr><td className="p-3 text-center" colSpan={8}>در حال بارگذاری...</td></tr>
                )}
                {!isLoading && filteredOrders.map((row) => {
                  const isEditing = editingId === row.id;
                  return (
                    <tr key={row.id} className="border-t">
                      <td className="p-3">{row.id}</td>
                      <td className="p-3">{row.date}</td>
                      <td className="p-3">{row.items}</td>
                      <td className="p-3">{row.userName}</td>
                      <td className="p-3">{row.userNationalId}</td>
                      <td className="p-3">{row.amount}</td>
                      <td className="p-3">
                        {isEditing ? (
                          <select
                            className="rounded border px-2 py-1 bg-background"
                            value={draftStatus}
                            onChange={(e) => setDraftStatus(e.target.value as OrderStatus)}
                          >
                            <option value="پرداخت شده">پرداخت شده</option>
                            <option value="در حال پردازش">در حال پردازش</option>
                            <option value="مرجوع">مرجوع</option>
                          </select>
                        ) : (
                          row.status
                        )}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          {isEditing ? (
                            <>
                              <button className="rounded border px-3 py-1 hover:bg-blue-600 hover:text-white" onClick={saveEdit}>
                                ذخیره
                              </button>
                              <button className="rounded border px-3 py-1 hover:bg-blue-600 hover:text-white" onClick={cancelEdit}>
                                انصراف
                              </button>
                            </>
                          ) : (
                            <button
                              className="rounded border px-3 py-1 bg-background hover:bg-primary hover:text-white"
                              onClick={() => startEdit(row)}
                            >
                              ویرایش وضعیت
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {!isLoading && filteredOrders.length === 0 && (
                  <tr><td className="p-3 text-center text-foreground/70" colSpan={8}>
                    {rows.length === 0 ? "سفارشی یافت نشد." : "نتیجه‌ای برای فیلترهای انتخابی یافت نشد."}
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}


