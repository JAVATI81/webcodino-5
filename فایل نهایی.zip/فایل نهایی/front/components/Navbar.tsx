"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

const links: Array<{ href: string; label: string }> = [
  { href: "/", label: "خانه" },
  { href: "/products", label: "محصولات" },
  { href: "/projects", label: "پروژه‌ها" },
  { href: "/blog", label: "وبلاگ" },
  { href: "/faq", label: "سوالات متداول" },
  { href: "/about", label: "درباره ما" },
  { href: "/contact", label: "تماس با ما" },
];

export default function Navbar() {
  const pathname = usePathname();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const onScroll = () => setIsScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true } as AddEventListenerOptions);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`sticky top-4 z-50 mx-4 sm:mx-8 md:mx-12 lg:mx-16 xl:mx-20 rounded-2xl border transition-colors backdrop-blur-md ${
      mounted && isScrolled ? "bg-background/80" : "bg-background/20"
    }`}>
      {/* کنترل باز/بسته منوی موبایل - باید هم‌سطح با منوی کشویی باشد تا peer کار کند */}
      <input id="nav-toggle" type="checkbox" className="peer hidden" />

      <div className="mx-auto relative flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <Link href="/" className="text-lg font-bold">
            وب‌کدینو
          </Link>
        </div>
        {/* دسکتاپ: منوی وسط */}
        <nav className="hidden md:flex gap-6 absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-transparent">
          {links.map((link) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`text-base transition-colors hover:text-primary ${
                  isActive ? "text-primary font-semibold" : "text-foreground/80"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
        {/* موبایل: دکمه همبرگری */}
        <label htmlFor="nav-toggle" className="md:hidden p-2 rounded hover:bg-primary hover:text-white cursor-pointer">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </label>
        <div className="flex items-center gap-3">
          <Link href="/account" aria-label="حساب کاربری" className="p-2 rounded hover:bg-blue-600 hover:text-white">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              width="22"
              height="22"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
              aria-hidden="true"
            >
              <circle cx="12" cy="7.5" r="3.5" />
              <path d="M4 20c0-3.8 4-6.5 8-6.5s8 2.7 8 6.5" />
            </svg>
          </Link>
        </div>
      </div>
      {/* منوی کشویی موبایل */}
      <div className="md:hidden peer-checked:block hidden px-4 pb-3">
        <nav className="flex flex-col gap-2 border-t pt-3">
          {links.map((link) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded px-3 py-2 transition-colors hover:bg-blue-600 hover:text-white ${
                  isActive ? "bg-blue-100 text-blue-700" : "text-foreground/80"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}


